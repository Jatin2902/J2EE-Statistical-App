# J2EE-Web-App
A web application using JSF that dynamically generates statistcs and analytics. It is intuitive and GUI based.  

This needs to run on Apache Tomcat. All relevant libraries are present. 
